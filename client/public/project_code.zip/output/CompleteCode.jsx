import React from "react";
import { 
  ShieldCheck, 
  Code, 
  BookOpen, 
  HeadphonesIcon, 
  FileCheck, 
  Globe, 
  Lock, 
  Clock, 
  TrendingUp,
  Mail,
  Phone
} from "lucide-react";
import { motion } from "framer-motion";

// --- Components ---

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "Services", href: "#services" },
    { name: "Taxation", href: "#taxation" },
    { name: "About", href: "#about" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <header className={`fixed top-0 w-full z-50 transition-all ${scrolled ? "bg-white shadow-md py-2" : "bg-transparent py-4"}`}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="text-2xl font-bold text-blue-900">PROCENTRILIX</div>
        <nav className="hidden md:flex gap-8 items-center">
          {navLinks.map(link => (
            <a key={link.name} href={link.href} className="text-gray-700 hover:text-blue-600 font-medium">{link.name}</a>
          ))}
          <a href="#contact" className="bg-blue-900 text-white px-6 py-2 rounded-full font-bold">Get a Quote</a>
        </nav>
      </div>
    </header>
  );
};

const ServiceCard = ({ title, description, icon, delay = 0 }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay }}
    className="group bg-white p-8 rounded-3xl border border-gray-100 shadow-lg hover:shadow-2xl transition-all"
  >
    <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all">
      {icon}
    </div>
    <h3 className="text-2xl font-bold mb-4">{title}</h3>
    <p className="text-gray-600 leading-relaxed">{description}</p>
  </motion.div>
);

const TaxationSection = () => {
  const [activeTab, setActiveTab] = React.useState("usa");
  const data = {
    usa: { title: "USA", services: ["Tax Filings (Federal & State)", "Bookkeeping (QuickBooks, Xero)", "Payroll Processing", "Audit Detection & Resolution", "Business Incorporation & Compliance"] },
    uk: { title: "UK", services: ["VAT Registration & Filings", "Business Tax Filings", "Individual Tax Filings", "Bookkeeping Processing", "Payroll Processing"] },
    uae: { title: "UAE", services: ["VAT Registration & Compliance", "VAT Deregistration & Compliance", "Corporate Tax Filings", "Bookkeeping Processing", "Payroll Processing"] }
  };

  return (
    <section id="taxation" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">Taxation Services</h2>
        <div className="flex justify-center gap-4 mb-12">
          {Object.keys(data).map(key => (
            <button 
              key={key}
              onClick={() => setActiveTab(key)}
              className={`px-8 py-3 rounded-xl font-bold transition-all ${activeTab === key ? "bg-blue-900 text-white" : "bg-white text-gray-600 border"}`}
            >
              {data[key].title}
            </button>
          ))}
        </div>
        <div className="bg-white p-8 rounded-3xl shadow-xl max-w-3xl mx-auto">
          <ul className="space-y-4">
            {data[activeTab].services.map(s => (
              <li key={s} className="flex items-center gap-3 text-gray-700">
                <ShieldCheck className="text-green-500 w-5 h-5" /> {s}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};

// --- Main Page ---

export default function ProcentrilixApp() {
  return (
    <div className="antialiased text-slate-900">
      <Navbar />
      
      {/* Hero */}
      <section id="home" className="pt-32 pb-20 bg-slate-900 text-white relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10 text-center">
          <motion.h1 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-5xl md:text-7xl font-bold mb-8"
          >
            Centralizing Expertise for the <span className="text-blue-400">Digital Future</span>
          </motion.h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-10">
            Enterprise-grade IT and Non-IT services with a focus on quality, compliance, and security.
          </p>
          <div className="flex justify-center gap-4">
            <a href="#services" className="bg-blue-500 px-8 py-4 rounded-xl font-bold">Our Services</a>
            <a href="#contact" className="border border-white/20 px-8 py-4 rounded-xl font-bold">Contact Us</a>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <ServiceCard title="Remediation" description="Compliance and system vulnerability handling." icon={<ShieldCheck />} />
            <ServiceCard title="Web Dev" description="Custom scalable web applications." icon={<Code />} delay={0.1} />
            <ServiceCard title="E-publishing" description="Digital publishing and XML conversion." icon={<BookOpen />} delay={0.2} />
          </div>
        </div>
      </section>

      <TaxationSection />

      {/* Security */}
      <section id="about" className="py-24 bg-white">
        <div className="container mx-auto px-4 text-center max-w-4xl">
          <div className="bg-slate-50 p-12 rounded-[3rem] border border-slate-100">
            <ShieldCheck className="w-16 h-16 mx-auto mb-8 text-blue-900" />
            <h2 className="text-4xl font-bold mb-6">Quality & Security</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              We follow structured workflows, multi-level quality checks, and strict data protection policies to protect every client asset.
            </p>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-4xl font-bold mb-8">Contact Us</h2>
            <div className="space-y-6">
              <p className="flex items-center gap-4"><Mail className="text-blue-400" /> info@procentrilix.com</p>
              <p className="flex items-center gap-4"><Phone className="text-blue-400" /> +91 7993521407</p>
              <p className="flex items-center gap-4"><Globe className="text-blue-400" /> Hyderabad, India</p>
            </div>
          </div>
          <form className="bg-white p-8 rounded-3xl text-slate-900 space-y-4">
            <input className="w-full p-4 bg-slate-50 border rounded-xl" placeholder="Your Name" />
            <input className="w-full p-4 bg-slate-50 border rounded-xl" placeholder="Email" />
            <textarea className="w-full p-4 bg-slate-50 border rounded-xl" rows="4" placeholder="Message"></textarea>
            <button className="w-full bg-blue-900 text-white py-4 rounded-xl font-bold">Send Message</button>
          </form>
        </div>
      </section>
    </div>
  );
}
